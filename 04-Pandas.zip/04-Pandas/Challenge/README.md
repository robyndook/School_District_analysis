# Module 4 | Assignment - PyCitySchools

Use Python and the Pandas library to analyze school district data and showcase trends in school performance.
